<?php
session_start();
session_regenerate_id(true);

require 'classes/database.php';
require 'classes/user.php';
require 'classes/friend.php';
//require 'classes/masage.php';


$db_obj = new Database();
$db_connection = $db_obj->dbConnection();


$user_obj = new User($db_connection);

$frnd_obj = new Friend($db_connection);
?>